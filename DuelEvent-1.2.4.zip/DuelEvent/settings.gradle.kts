rootProject.name = "DuelEvent"
